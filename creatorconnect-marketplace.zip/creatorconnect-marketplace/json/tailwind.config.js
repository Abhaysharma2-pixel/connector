{
  "content": [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  "theme": {
    "extend": {
      "colors": {
        "navy": {
          "50": "#f8f9fa",
          "100": "#e9ecef",
          "200": "#dee2e6",
          "300": "#ced4da",
          "400": "#adb5bd",
          "500": "#6c757d",
          "600": "#495057",
          "700": "#343a40",
          "800": "#212529",
          "900": "#0d1117"
        },
        "purple": {
          "50": "#f3e8ff",
          "100": "#ecd5fe",
          "200": "#d8b4fe",
          "300": "#c084fc",
          "400": "#a855f7",
          "500": "#8b5cf6",
          "600": "#7c3aed",
          "700": "#6d28d9",
          "800": "#5b21b6",
          "900": "#4c1d95"
        }
      },
      "fontFamily": {
        "sans": ["Inter", "sans-serif"],
        "serif": ["Merriweather", "serif"]
      }
    }
  },
  "plugins": []
}
