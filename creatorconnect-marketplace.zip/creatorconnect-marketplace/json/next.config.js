{
  "reactStrictMode": true,
  "swcMinify": true,
  "images": {
    "domains": ["res.cloudinary.com", "lh3.googleusercontent.com"]
  },
  "env": {
    "NEXT_PUBLIC_APP_URL": "process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'"
  },
  "async redirects()": [
    {
      "source": "/admin",
      "destination": "/admin/dashboard",
      "permanent": true
    }
  ]
}
